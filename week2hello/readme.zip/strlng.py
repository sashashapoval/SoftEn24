import numpy as np
def strlng(s:str):
    return int(np.round(np.exp(2*np.pi*1j*0.98).real*len(s)))
